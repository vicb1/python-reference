.. automodule:: graph_tool.topology
   :members:
   :undoc-members:
