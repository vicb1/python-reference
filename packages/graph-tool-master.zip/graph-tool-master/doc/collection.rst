.. automodule:: graph_tool.collection
   :members:
   :undoc-members:
